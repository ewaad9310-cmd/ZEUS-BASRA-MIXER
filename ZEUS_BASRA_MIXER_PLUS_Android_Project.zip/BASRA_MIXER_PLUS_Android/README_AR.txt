BASRA MIXER PLUS — مشروع أندرويد

هذا مشروع Android Studio جاهز للبناء، وليس ملف APK مثبتاً.

طريقة إخراج APK:
1) نزّل Android Studio على الكمبيوتر.
2) فك ضغط الملف وافتح مجلد BASRA_MIXER_PLUS_Android في Android Studio.
3) انتظر اكتمال Gradle Sync وتنزيل الاعتماديات.
4) من القائمة: Build > Build Bundle(s) / APK(s) > Build APK(s).
5) ستجد APK داخل app/build/outputs/apk/debug/

ملاحظات:
- التطبيق يحتوي واجهة المكسر المرفقة ويعمل محلياً بعد تثبيته.
- يحتاج إذن المايك عند تشغيل المايك.
- اختبره بسماعات رأس لتجنب صفير رجوع الصوت.
- لا ترفع مستوى الصوت إلى حد يسبب ألماً أو انزعاجاً.
- بناء APK يتطلب Android SDK واتصال إنترنت أول مرة لتنزيل Gradle والاعتماديات.

حقوق الواجهة: © 2026 ZEUS — Telegram: @KW_PK
